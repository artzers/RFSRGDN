import numpy as np 

from scipy.spatial.distance import cdist 
from skimage.morphology import ball,dilation, skeletonize_3d

def fast_hist(pred, label, n):
    k = (label >= 0) & (label < n)
    return np.bincount(\
            n * label[k].astype(int) + pred[k], minlength=n ** 2).reshape(n, n)

def batch_soft_metric(preds,labels,thres = 1):
    assert len(preds.shape) == len(labels.shape) == 4
    metric = np.zeros((preds.shape[0],4))
    assert preds.shape == labels.shape
    i = 0
    for pred,label in zip(preds,labels):
        metric[i] = soft_metric(pred,label,thres)
        i += 1
    return metric,np.mean(metric,axis = 0)


def batch_soft_metric_Whole(preds,labels,thres = 1):
    assert preds.shape == labels.shape

    metric = soft_metric(preds,labels,thres)

    return metric,np.mean(metric,axis = 0)


def soft_metric(pred,label,thres = 1):
    label=label>0
    label=np.array(label,np.int32)
    pred=pred>0
    pred=np.array(pred,np.int32)

    label_expand = dilation(label,ball(thres))
    #iou = np.sum(label_expand*pred)
    pred_expand = dilation(pred,ball(thres))
    
    prec = np.sum(pred*label_expand)/(np.sum(pred)+ 1e-10)
    recall = np.sum(label*pred_expand)/(np.sum(label)+ 1e-10)
    
    rate = np.sum(label)/label.size
    dice = 2/(1/prec+1/recall)
    return np.array([dice,prec,recall,rate])

def calc_dic(n_objects_gt, n_objects_pred):
    return np.abs(n_objects_gt - n_objects_pred)


def calc_dice(gt_seg, pred_seg):

    nom = 2 * np.sum(gt_seg * pred_seg)
    denom = np.sum(gt_seg) + np.sum(pred_seg)

    dice = float(nom) / float(denom)
    return dice


def calc_bd(ins_seg_gt, ins_seg_pred):

    gt_object_idxes = list(set(np.unique(ins_seg_gt)).difference([0]))
    pred_object_idxes = list(set(np.unique(ins_seg_pred)).difference([0]))

    best_dices = []
    for gt_idx in gt_object_idxes:
        _gt_seg = (ins_seg_gt == gt_idx).astype('bool')
        dices = []
        for pred_idx in pred_object_idxes:
            _pred_seg = (ins_seg_pred == pred_idx).astype('bool')

            dice = calc_dice(_gt_seg, _pred_seg)
            dices.append(dice)
        best_dice = np.max(dices)
        best_dices.append(best_dice)

    best_dice = np.mean(best_dices)

    return best_dice


def calc_sbd(ins_seg_gt, ins_seg_pred):

    _dice1 = calc_bd(ins_seg_gt, ins_seg_pred)
    _dice2 = calc_bd(ins_seg_pred, ins_seg_gt)
    return min(_dice1, _dice2)




def multi_metric(metric):
    recall = metric[2]/(metric[2]+metric[3]+1e-10)
    precision = metric[0]/(metric[0]+metric[1]+1e-10)
    dice = 2*recall*precision/(recall+precision+1e-10)
    #rate = (metric[2]+metric[3])/metric[4]
    return dice,precision,recall

def per_class_iu(hist):
    return np.diag(hist) / (hist.sum(1) + hist.sum(0) - np.diag(hist))
def multi_class_metric(hist,class_inds = [1,2,3,4]):
    hist = hist + 1e-5 
    selected_hist = hist[class_inds][:,class_inds]

    tp = np.sum(selected_hist)
    
    fp = np.sum(hist[:,class_inds]) - tp
    fn = np.sum(hist[class_inds,:]) - tp

    prec = round(tp/(tp + fp),4)
    sens = round(tp/(fn + tp),4)
    dsc = round(2*tp/(fn + fp + 2*tp),4)
    #print(tp,fp,fn)
    generes_count = np.sum(hist,axis = 1)
    generes_count_sel = np.sum(generes_count[class_inds])
    generes_rate = generes_count_sel/np.sum(generes_count)
    return dsc,prec,sens,generes_rate

def dsc(pred,label,num_classes):
    hist = fast_hist(pred,label,n)
    #dsc = 2*per_class_iu(hist)
    dsc =2* np.diag(hist)/ (hist.sum(1) + hist.sum(2))
    return dsc 

def jacc(pred,label,num_classes):
    dsc = dsc(pred,label,num_classes)
    jacc = dsc/(2 - dsc)
    return jacc

def prec_rec(pred,label,num_classes):
    hist = fast_hist(pred,label,n)
    return np.diag(hist)/hist(0)

    
