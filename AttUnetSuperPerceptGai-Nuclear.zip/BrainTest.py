import os, tifffile
import Net, torch
import numpy as np
from models import AttentionUNetGai
import time
from tqdm import tqdm

# globalMean,globalStd = 892, 9733.
# reader = TDATAReader()
# reader.SetInputFileName('D:/SR-Sample/Germany/20180201/5Xmostd/TEST2.mostd')
# img = tifffile.imread('E:\Document\SuperRecon/lowCrop.tif')
#img = img[:160,:660,:660]
#tifffile.imwrite('lowCropCrop.tif',img)

# img = tifffile.imread('lowCropCrop.tif')
img = tifffile.imread('E:\Document\SuperRecon\RCAN\Confocal_2_STED/Nuclear_Pore_complex/test/testraw/np_33.tif')

minLowRange=[0,0,0]#[1800,3300,550]#z,y,x
minLowRange = minLowRange[-1::-1]
maxLowRange = img.shape
# maxLowRange = maxLowRange[-1::-1]#reverse
# readRange = [60, 60, 60]
zMinLowList = []
zMaxLowList = []
yMinLowList = []
yMaxLowList = []
xMinLowList = []
xMaxLowList = []

zMinLowList=[0]
zMaxLowList=[6]

for k in range(minLowRange[1], maxLowRange[1] - 63,48):
    #for k in range(minLowRange[1], maxLowRange[1] - 40,20):
    yMinLowList.append(k)
    yMaxLowList.append(k+64)#59

if yMaxLowList[-1] < maxLowRange[1]:
    yMaxLowList.append(maxLowRange[1])
    yMinLowList.append(maxLowRange[1] - 64)

for k in range(minLowRange[2], maxLowRange[2] - 63,48):
    xMinLowList.append(k)
    xMaxLowList.append(k+64)

if xMaxLowList[-1] < maxLowRange[2]:
    xMaxLowList.append(maxLowRange[2])
    xMinLowList.append(maxLowRange[2] - 64)

# for k in range(minLowRange[0], maxLowRange[0] - 40, 20):
#     zMinLowList.append(k)
#     zMaxLowList.append(k+59)
#
# for k in range(minLowRange[1], maxLowRange[1] - 40,20):
#     #for k in range(minLowRange[1], maxLowRange[1] - 40,20):
#     yMinLowList.append(k)
#     yMaxLowList.append(k+59)#59
#
# for k in range(minLowRange[2], maxLowRange[2] - 40,20):
#     xMinLowList.append(k)
#     xMaxLowList.append(k+59)
#
#pretrained_net = torch.load('D:/Python/SR201905/20190528-DualGAN-5X20X/saved_models/G_AB_36000.pth')
pretrained_net = AttentionUNetGai(in_channel = 1, num_class = 1)
#pretrained_net.load_state_dict(torch.load('D:/Python/SR201905/20190528-DualGAN-5X20X/G_AB_91000.pth'))
pretrained_net.load_state_dict(torch.load('./saved_models/G_AB_277000.pth'))
pretrained_net = pretrained_net.cuda(0)
pretrained_net.eval()
torch.set_grad_enabled(False)
torch.cuda.empty_cache()

# lowResImg = np.zeros((yMaxLowList[-1]-yMinLowList[0]+1, xMaxLowList[-1] - xMinLowList[0]+1),dtype=np.uint16)
# for i in range(1):#TODO
#     for j in range(len(yMinLowList)):
#         for k in range(len(xMinLowList)):
#             print('processing %d-%d, %d-%d %d-%d'%(xMinLowList[k], xMaxLowList[k],
#                                                    yMinLowList[j], yMaxLowList[j],
#                                                    zMinLowList[i], zMaxLowList[i]))
#             lowImg = reader.SelectIOR(xMinLowList[k], xMaxLowList[k],
#                                       yMinLowList[j], yMaxLowList[j],
#                                       zMinLowList[i], zMaxLowList[i],1)
#             lowProj = lowImg[10:20, 20:40, 20:40]
#             lowProj = np.max(lowProj,axis=0)
#             lowResImg[yMinLowList[j]+20-yMinLowList[0]:yMinLowList[j]+40-yMinLowList[0], \
#                 xMinLowList[k]+20-xMinLowList[0]:xMinLowList[k]+40-xMinLowList[0]] = lowProj
# tifffile.imwrite('E:/Germany/train_dataset_4to20_16bit/lowBrainTest.tif',lowResImg)

lowMeanVal = 0.20
lowStdVal = 0.20
highMeanVal = 0.20
highStdVal = 0.20
highImg = np.zeros_like(img)
xBase = xMinLowList[0]
yBase = yMinLowList[0]
zBase = zMinLowList[0]
time_start = time.time()
for i in range(len(zMinLowList)):#TODO
    for j in range(len(yMinLowList)):
        for k in range(len(xMinLowList)):
            print('processing %d-%d, %d-%d %d-%d'%(xMinLowList[k], xMaxLowList[k],
                                                   yMinLowList[j], yMaxLowList[j],
                                                   zMinLowList[i], zMaxLowList[i]))
            # lowImg = reader.SelectIOR(xMinLowList[k], xMaxLowList[k],
            #                           yMinLowList[j], yMaxLowList[j],
            #                           zMinLowList[i], zMaxLowList[i],1)
            #print('Cache : %d'%len(reader.imageCacheManager.cacheList))
            lowImg = img[zMinLowList[i]: zMaxLowList[i],
                     yMinLowList[j]: yMaxLowList[j],
                     xMinLowList[k]: xMaxLowList[k]]

            lowImg = np.array(lowImg, dtype=np.float32)
            lowImg = (lowImg - lowMeanVal) / (lowStdVal)
            lowImg = np.expand_dims(lowImg, axis=0)
            lowImg = np.expand_dims(lowImg, axis=0)
            lowImg = torch.from_numpy(lowImg).float()
            lowImg = lowImg.cuda(0)
            pre2 = pretrained_net(lowImg)
            saveImg = pre2.cpu().data.numpy()[0, 0, :, :, :]
            saveImg *= lowStdVal
            saveImg += lowMeanVal
            #saveImg = np.uint16(np.maximum(np.minimum(saveImg, 65535), 0))
            # savePath = os.path.join('E:/Germany/train_dataset_5to20_cleaned/brainTest/'
            #                         '%d_%d_%d_pre.tif'%(xMinLowList[k],
            #                                             yMinLowList[j],
            #                                             zMinLowList[i]))
            # tifffile.imwrite(savePath, saveImg[60:120, 60:120, 60:120])

            highImg[(zMinLowList[i]-zBase):(zMinLowList[i]-zBase+6),
            (yMinLowList[j]-yBase):(yMinLowList[j]-yBase+64),
            (xMinLowList[k]-xBase):(xMinLowList[k]-xBase)+64] = saveImg#[24:120, 24:120, 24:120]

            # savePath = os.path.join('E:/Germany/train_dataset_4to20_16bit/brainTest/'
            #                         '%d_%d_%d_pre.tif'%(xMinLowList[k],
            #                                             yMinLowList[j],
            #                                             zMinLowList[i]))
            # tifffile.imwrite(savePath, saveImg)
            # tiff = TIFFimage(saveImg, description='')
            # tiff.write_file(savePath, compression='lzw', verbose=False)
            # del tiff
            # tiff = None
            # io.use_plugin('tifffile')
            # io.imsave(savePath, saveImg)
            # tif = TIFF.open(savePath, mode='w')
            # tif.write_image(saveImg, compression='lzw')
            # tif.close()
#tifffile.imwrite('D:/work_note/DualSR3D/brainregion/highcrop5.tif', highImg[60:-60,60:-60,60:-60])
time_end = time.time()
print('totally time cost', time_end - time_start)
tifffile.imwrite('./out.tif', highImg)
# tifffile.imwrite('.//test/highcrop.tif', highImg[24:-24,24:-24,24:-24])

#montage images
# srcPath = 'E:/Germany/train_dataset_4to20_16bit/brainTest/'
# filePost = '_350_pre.tif'
# fileList = []
# xMin = 100000
# xMax = 0
# yMin = 100000
# yMax = 0
# for name in  os.listdir(srcPath):
#     if name.endswith(filePost):
#         fileList.append(name)
#         nameList = name[:-12].split('_')
#         xId = int(nameList[0])
#         yId = int(nameList[1])
#         xMin = min(xMin, xId)
#         yMin = min(yMin, yId)
#         xMax = max(xMax, xId)
#         yMax = max(yMax, yId)
#
# xLen = xMax - xMin + 60
# yLen = yMax - yMin + 60

# for name in tqdm(fileList):
#     #nameList = name[:-12].split('_')
#     img = tifffile.imread(os.path.join(srcPath, name))
#     img = img[40:80,100:200,100:200]
#     proj = np.max(img, axis=0)
#     proj = proj
#     tifffile.imwrite(os.path.join('E:/Germany/train_dataset_4to20_16bit/brainTestProj/',name),
#                                   proj)

    # xId = int(nameList[0]) - xMin
    # yId = int(nameList[1]) - yMin
    # xPos = xId * 5
    # yPos = yId * 5
    # xBeg = xPos + 100
    # yBeg = yPos + 100
    # resImg[xBeg:xBeg+100, yBeg:yBeg+100] = proj


# srcPath = 'E:/Germany/train_dataset_4to20_16bit/brainTestProj/'
# fileList = os.listdir(srcPath)
# resImg = np.zeros((yLen*5, xLen*5),dtype=np.uint16)
# for name in tqdm(fileList):
#     proj = tifffile.imread(os.path.join(srcPath, name))
#     nameList = name[:-12].split('_')
#     xId = int(nameList[0]) - xMin
#     yId = int(nameList[1]) - yMin
#     xPos = xId * 5
#     yPos = yId * 5#super resolution
#     xBeg = xPos + 100
#     yBeg = yPos + 100
#     resImg[yBeg:yBeg+100, xBeg:xBeg+100] = proj
# tifffile.imwrite('E:/Germany/train_dataset_4to20_16bit/brainTestProj.tif',resImg)


