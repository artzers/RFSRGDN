import os, torch
import numpy as np
#import pynvml
from torch import nn
from torch.nn import functional as F
from vis import vis_tool
import tifffile
from torch.utils.data import DataLoader
from Util import GetMemoryDataSetAndCrop
import math,time
from tqdm import tqdm

#from Net import Trainer
import Net
#import ParallelNet

'''
python -m visdom.server

在浏览器中打开：

http://localhost:8097/
'''


def CalcMeanStd(path):
    srcPath = path
    fileList = os.listdir(srcPath)
    fileNum = len(fileList)

    globalMean = 0
    globalStd = 0

    for name in tqdm(fileList):
        img = tifffile.imread(os.path.join(srcPath, name))
        mean = np.mean(img)
        globalMean += mean
    globalMean /= fileNum


    for name in tqdm(fileList):
        img = tifffile.imread(os.path.join(srcPath, name))
        img = img.astype(float)
        img -= globalMean
        sz = img.shape[0] * img.shape[1] * img.shape[2]
        globalStd += np.sum(img ** 2) / float(sz)
    globalStd = (globalStd / len(fileList)) ** (0.5)

    print(globalMean)
    print(globalStd)
    return globalMean,globalStd


def CalcMeanMax(path):
    srcPath = path
    fileList = os.listdir(srcPath)
    fileNum = len(fileList)

    maxVal = 0
    for name in tqdm(fileList):
        img = tifffile.imread(os.path.join(srcPath, name))
        maxVal = np.maximum(maxVal, np.max(img))

    print(maxVal)

    globalMean = 0
    globalStd = 0

    for name in tqdm(fileList):
        img = tifffile.imread(os.path.join(srcPath, name))
        mean = np.mean(img)
        globalMean += mean
    globalMean /= fileNum
    print(globalMean)
    return globalMean,maxVal

#hrPath = 'D:/SR-Sample/Germany/EstimatePSF/Train10X/newDst/'
#midPath = 'D:/SR-Sample/Germany/EstimatePSF/Train10X/newDst2X200ill/'
#hrPath = 'D:/SR-Sample/Germany/EstimatePSF/Train10X/clean/newDst/'
#midPath = 'D:/SR-Sample/Germany/EstimatePSF/Train10X/clean/newDst2X200ill/'
#lrPath = 'D:/SR-Sample/Germany/EstimatePSF/dst4xblur/'
# hrPath = 'E:/Germany/train_dataset_5to20_cleaned/manual/20X/nousescale/'
# midPath = 'E:/Germany/train_dataset_5to20_cleaned/manual/5X/nousescale/'
#hrPath = 'D:/SR-Sample/Germany/20180201/20190614NewSample/20X/'
#midPath = 'D:/SR-Sample/Germany/20180201/20190614NewSample/5X/'
# hrPath = 'E:/Germany/train_dataset_5to20_cleaned/20190709Sample/20X/'
# midPath = 'E:/Germany/train_dataset_5to20_cleaned/20190709Sample/5X/'
#hrPath = 'E:/Germany/train_dataset_5to20_cleaned/chen_dense_register5X/HrSample/'
#midPath = 'E:/Germany/train_dataset_5to20_cleaned/chen_dense_register5X/LrSample/'
imgPath = "E:\Document\SuperRecon\RCAN\Confocal_2_STED\Microtubule\Training/raw/"
maskPath = "E:\Document\SuperRecon\RCAN\Confocal_2_STED\Microtubule\Training\gt/"

# globalMean = np.array([6], dtype=np.float32)#55
# globalStd = np.array([14], dtype=np.float32)#17
# globalMax = np.array([255], dtype=np.float32)

env = 'Weiguan'
globalDev = 'cuda:0'
globalDeviceID = 0
# train_dataset = GetTrainDataSet3(lrPath, midPath,hrPath, globalMean, globalStd)

if __name__ == '__main__':
    lowMean,lowStd = 0.20,0.20#CalcMeanStd(imgPath)#2000., 8000.#CalcMeanStd(midPath) #600.,3500./2
    highMean, highStd = 0.20,0.20#CalcMeanStd(maskPath)#2400,10000./2
    # exit(0)#600，400， 2500，2000
    # train_dataset = GetTrainProbDataSet2(midPath, hrPath, #probPath,
    #                                   lowMean,lowStd,
    #                                   highMean, highStd)
    # train_dataset = GetTrainDataSet2(midPath, hrPath)
    train_dataset = GetMemoryDataSetAndCrop(imgPath, maskPath, [64, 64], 100, lowMean, lowStd, highMean, highStd)
    train_loader = DataLoader(train_dataset, batch_size=1, shuffle=True,num_workers=1)
    #test_loader = DataLoader(test_dataset, batch_size=1, shuffle=True,num_workers=1)
    visdomable = True
    if visdomable == True:
        logger = vis_tool.Visualizer(env=env)
        logger.reinit(env=env)

    Net.logger = logger
    Net.lowMean = lowMean
    Net.lowStd = lowStd
    Net.highMean = highMean
    Net.highStd = highStd
    #trainer = Net.Trainer(data_loader=train_loader, test_loader=test_loader)
    trainer = Net.TrainerDualWGANGP(data_loader=train_loader, test_loader=None)

    time_start = time.time()
    trainer.Train(turn=500)
    time_end = time.time()
    print('totally time cost', time_end - time_start)
    #Test(globalMean,globalStd)
    # MakeProj('E:/Germany/train_dataset_4to20_16bit/predict4Xrest/',
    #          'E:/Germany/train_dataset_4to20_16bit/predict4Xrestproj/')
