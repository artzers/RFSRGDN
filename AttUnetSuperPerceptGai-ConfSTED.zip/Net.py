import os, torch, tifffile
import numpy as np
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader
from torch.optim import lr_scheduler as lrs
import torch.nn.utils as utils
from torch.utils.checkpoint import checkpoint

from scipy.ndimage.interpolation import zoom
import itertools
from torch.autograd import Variable
import torch.autograd as autograd
from models import AttentionUNetGai, DegradeNet, LowDiscriminator, HighDiscriminator

from Util import PixelUpsampler3D, RestoreNetImg, calc_psnr,  \
default_conv3d, prepare, RestoreNetImgV2, ResBlock3D

logger = None

def get_style_loss(f1,f2):
    #same size
    _,c,d,h,w = f1.size()
    f1 = f1.view(c, d * h * w)
    gram1 = torch.mm(f1, f1.t())

    f2 = f2.view(c, d * h * w)
    gram2 = torch.mm(f2, f2.t())
    layer_style_loss = torch.mean((gram1 - gram2) ** 2)
    return layer_style_loss

def weights_init_normal(m):
    classname = m.__class__.__name__
    if classname.find("Conv") != -1:
        torch.nn.init.normal_(m.weight.data, 0.0, 0.02)
    elif classname.find("BatchNorm2d") != -1:
        torch.nn.init.normal_(m.weight.data, 1.0, 0.02)
        torch.nn.init.constant_(m.bias.data, 0.0)

class TrainerDualWGANGP:
    def __init__(self,
                 data_loader,
                 test_loader,
                 scheduler=lrs.StepLR,
                 dev='cuda:0', devid=0):
        self.dataLoader = data_loader
        self.testLoader = test_loader
        # self.scheduler = scheduler(
        #     self.optimizer, step_size=2000, gamma=0.8, last_epoch=-1)
        self.dev = dev
        self.cudaid = devid

        # Loss function
        self.adversarial_loss = torch.nn.MSELoss()
        self.cycle_loss1 = torch.nn.SmoothL1Loss(reduction='mean')
        self.cycle_loss2 = torch.nn.SmoothL1Loss(reduction='mean')

        # Loss weights
        self.lambda_adv = 1
        self.lambda_cycle = 10
        self.lambda_gp = 10

        # Initialize generator and discriminator
        self.G_AB = AttentionUNetGai(in_channel = 1, num_class = 1)
        self.G_BA = DegradeNet()
        self.D_A = LowDiscriminator()
        self.D_B = HighDiscriminator()

        # self.G_AB.load_state_dict(torch.load('./saved_models//G_AB_49500.pth'))
        # self.G_BA.load_state_dict(torch.load('./saved_models//G_BA_49500.pth'))
        # self.D_A.load_state_dict(torch.load('./saved_models//D_A_49500.pth'))
        # self.D_B.load_state_dict(torch.load('./saved_models//D_B_49500.pth'))
        #self.G_AB.load_state_dict(torch.load('.//G_AB_3500.pth'))
        #self.G_BA.load_state_dict(torch.load('./G_BA_3500.pth'))
        #self.D_A.load_state_dict(torch.load('./D_A_3500.pth'))
        #self.D_B.load_state_dict(torch.load('./D_B_3500.pth'))

        #self.G_AB.apply(weights_init_normal)
        # self.G_BA.apply(weights_init_normal)
        # self.D_A.apply(weights_init_normal)
        # self.D_B.apply(weights_init_normal)

        self.G_AB.cuda(self.cudaid)
        self.G_BA.cuda(self.cudaid)
        self.D_A.cuda(self.cudaid)
        self.D_B.cuda(self.cudaid)
        #self.cycle_loss.cuda(self.cudaid)
        # self.G_AB = nn.DataParallel(self.G_AB.cuda())
        # self.G_BA = nn.DataParallel(self.G_BA.cuda())
        # self.D_A = nn.DataParallel(self.D_A.cuda())
        # self.D_B = nn.DataParallel(self.D_B.cuda())

        # Optimizers
        lr = 0.00001
        self.optimizer_G = torch.optim.Adam([{'params': itertools.chain(self.G_AB.parameters(), \
                                                                        self.G_BA.parameters()), \
                                              'initial_lr': lr}], lr=lr)
        self.optimizer_D_A = torch.optim.RMSprop(params=[{'params':self.D_A.parameters(), \
                                                          'initial_lr':lr}], \
                                                   lr=lr)#RMSprop
        self.optimizer_D_B = torch.optim.RMSprop(params=[{'params': self.D_B.parameters(), \
                                                          'initial_lr': lr}], \
                                                 lr=lr)  # RMSprop
        #self.optimizer_D_B = torch.optim.RMSprop(self.D_B.parameters(), lr=0.0001)

        self.scheduler_G = scheduler(self.optimizer_G, step_size=10000, gamma=0.9, last_epoch=-1)#36000
        self.scheduler_D_A = scheduler(self.optimizer_D_A, step_size=10000, gamma=0.9, last_epoch=-1)
        self.scheduler_D_B = scheduler(self.optimizer_D_B, step_size=10000, gamma=0.9, last_epoch=-1)

        #self.FloatTensor = torch.FloatTensor#torch.cuda.FloatTensor
        #self.LongTensor = torch.LongTensor#torch.cuda(self.cudaid).LongTensor

    def compute_gradient_penalty(self,D, real_samples, fake_samples, flag):
        """Calculates the gradient penalty loss for WGAN GP"""
        # Random weight term for interpolation between real and fake samples
        alpha = torch.FloatTensor(np.random.random((real_samples.size(0), 1, 1, 1, 1)))
        alpha = alpha.cuda(self.cudaid)
        # Get random interpolation between real and fake samples
        interpolates = (alpha * real_samples + ((1 - alpha) * fake_samples)).requires_grad_(True)
        validity = None
        if flag == True:
            validity,_,_,_ = D(interpolates)
        else:
            validity = D(interpolates)
        fake = Variable(torch.FloatTensor(np.ones(validity.shape)).cuda(self.cudaid), requires_grad=False)
        # Get gradient w.r.t. interpolates
        gradients = autograd.grad(
            outputs=validity,
            inputs=interpolates,
            grad_outputs=fake,
            create_graph=True,
            retain_graph=True,
            only_inputs=True,
        )[0]
        gradients = gradients.view(gradients.size(0), -1)
        gradient_penalty = ((gradients.norm(2, dim=1) - 1) ** 2).mean()
        return gradient_penalty


    def Train(self, turn=2):
        self.shot = -1
        torch.set_grad_enabled(True)

        for t in range(turn):

            # if self.gclip > 0:
            #     utils.clip_grad_value_(self.net.parameters(), self.gclip)

            for kk, (lowImg, highImg, gt) in enumerate(self.dataLoader):

                # torch.cuda.empty_cache()
                self.shot = self.shot + 1
                # torch.cuda.empty_cache()
                # self.scheduler.step()
                self.scheduler_G.step()
                self.scheduler_D_A.step()
                self.scheduler_D_B.step()
                # lrImg = (lowImg - lowMean) / lowStd
                # mrImg = (highImg - highMean) / highStd
                # lrImg = lrImg.cuda(self.cudaid)
                # mrImg = mrImg.cuda(self.cudaid)
                lrImg = lowImg.cuda(self.cudaid)
                mrImg = highImg.cuda(self.cudaid)

                self.optimizer_D_A.zero_grad()
                self.optimizer_D_B.zero_grad()

                # Generate a batch of images
                fake_A = self.G_BA(mrImg).detach()
                fake_B = self.G_AB(lrImg).detach()

                # ----------
                # Domain A
                # ----------

                # Compute gradient penalty for improved wasserstein training
                gp_A = self.compute_gradient_penalty(
                    self.D_A, lrImg.data, fake_A.data, True)
                # Adversarial loss
                self.D_A_lrImg,D_A_lrF1,D_A_lrF2,D_A_lrF3 = (self.D_A(lrImg))
                self.D_A_lrImg = torch.mean(self.D_A_lrImg)
                self.D_A_fakeA ,D_A_fakeF1,D_A_fakeF2,D_A_fakeF3= (self.D_A(fake_A))
                self.D_A_fakeA = torch.mean(self.D_A_fakeA)
                D_A_loss = -self.D_A_lrImg + self.D_A_fakeA + 0.1 * gp_A

                # ----------
                # Domain B
                # ----------

                # Compute gradient penalty for improved wasserstein training
                gp_B = self.compute_gradient_penalty(self.D_B, mrImg.data, fake_B.data, True)
                # Adversarial loss
                self.D_B_mrImg,D_B_mrF1,D_B_mrF2,D_B_mrF3 = self.D_B(mrImg)
                self.D_B_mrImg = torch.mean(self.D_B_mrImg)
                self.D_B_fakeB,D_B_fakeF1,D_B_fakeF2,D_B_fakeF3 = self.D_B(fake_B)
                self.D_B_fakeB = torch.mean(self.D_B_fakeB)
                D_B_loss = -self.D_B_mrImg + self.D_B_fakeB + 0.1 * gp_B

                self.perceptLoss = 10*( 0.2 * get_style_loss(D_B_mrF1, D_B_fakeF1)
                + 0.3 * get_style_loss(D_B_mrF2, D_B_fakeF2)
                + 0.5 * get_style_loss(D_B_mrF3, D_B_fakeF3) +
                                          0.2 * get_style_loss(D_A_lrF1, D_A_fakeF1)
                                          + 0.3 * get_style_loss(D_A_lrF2, D_A_fakeF2)
                                          + 0.5 * get_style_loss(D_A_lrF3, D_A_fakeF3)
                                          )

                # Total loss
                D_loss = 10*D_A_loss + 10*D_B_loss
                final_D_loss = self.perceptLoss + D_loss
                # if self.perceptLoss.item() <10:
                #     final_D_loss = self.perceptLoss + D_loss
                # else:
                #     final_D_loss = D_loss

                if True:#final_D_loss.item() <20
                    final_D_loss.backward()

                    torch.nn.utils.clip_grad_value_(self.D_A.parameters(), clip_value=1)
                    torch.nn.utils.clip_grad_value_(self.D_B.parameters(), clip_value=1)
                    torch.nn.utils.clip_grad_norm_(self.D_A.parameters(), 1)
                    torch.nn.utils.clip_grad_norm_(self.D_B.parameters(), 1)
                    torch.nn.utils.clip_grad_norm_(self.G_AB.parameters(), 1)
                    torch.nn.utils.clip_grad_norm_(self.G_BA.parameters(), 1)
                    torch.nn.utils.clip_grad_value_(self.G_AB.parameters(), clip_value=1)
                    torch.nn.utils.clip_grad_value_(self.G_BA.parameters(), clip_value=1)

                    self.optimizer_D_A.step()
                    self.optimizer_D_B.step()


                if kk % 2== 0:#True:#
                    # print('D_A(fakeA): %f D_B(fakeB):%f' % (self.D_A_fakeA.item(),
                    #                                         self.D_B_fakeB.item()))
                    # print('D_A(lr): %f D_B(mr):%f' % (self.D_A_lrImg.item(),
                    #                                         self.D_B_mrImg.item()))

                    # ------------------
                    #  Train Generators
                    # ------------------

                    self.optimizer_G.zero_grad()

                    # Translate images to opposite domain
                    fake_A = self.G_BA(mrImg)
                    fake_B = self.G_AB(lrImg)

                    # Reconstruct images
                    recov_A = self.G_BA(fake_B)
                    recov_B = self.G_AB(fake_A)

                    # Adversarial loss
                    G_adv = -torch.mean(self.D_A(fake_A)[0]) - torch.mean(self.D_B(fake_B)[0])
                    # Add super resolution loss
                    #G_sr = self.cycle_loss(fake_B, mrImg) + self.cycle_loss(fake_A, lrImg)
                    # Cycle loss
                    #G_cycle = self.cycle_loss(recov_A, lrImg) + self.cycle_loss(recov_B, mrImg)
                    # Total loss
                    #G_loss = self.lambda_adv * G_adv + self.lambda_cycle * G_cycle# + self.lambda_cycle * G_sr
                    #G_loss = G_adv + 50.0 * G_cycle  # + self.lambda_cycle * G_sr
                    lowCycle = 1 * self.cycle_loss1(
                       recov_A,lrImg)
                    highCycle = 1 * self.cycle_loss2(recov_B, mrImg)
                    # Total loss
                    G_loss = G_adv + lowCycle + highCycle

                    G_loss.backward()
                    torch.nn.utils.clip_grad_value_(self.D_A.parameters(), clip_value=1)
                    torch.nn.utils.clip_grad_value_(self.D_B.parameters(), clip_value=1)
                    torch.nn.utils.clip_grad_norm_(self.D_A.parameters(), 1)
                    torch.nn.utils.clip_grad_norm_(self.D_B.parameters(), 1)
                    torch.nn.utils.clip_grad_norm_(self.G_AB.parameters(), 1)
                    torch.nn.utils.clip_grad_norm_(self.G_BA.parameters(), 1)
                    torch.nn.utils.clip_grad_value_(self.G_AB.parameters(), clip_value=1)
                    torch.nn.utils.clip_grad_value_(self.G_BA.parameters(), clip_value=1)
                    self.optimizer_G.step()

                if self.shot % 20 == 0:

                    lr = self.scheduler_G.get_lr()[0]
                    lossVal = float(G_loss.cpu().data.numpy())
                    #print('epoch: %d batch: %d lr:%f loss:%f' % (t, self.shot, lr, lossVal))
                    #print('epoch: %d batch: %d lr:%f loss:%f' % (t, self.shot, self.lr, lossVal))
                    print("\r[Epoch %d] [Batch %d] [LR:%f] [D loss: %f] [G loss: %f, adv: %f,low cyc: %f, high cyc:%f, perp:%f]"
                          % (
                              t,
                              self.shot,
                              lr,
                              D_loss.item(),
                              G_loss.item(),
                              G_adv.item(),
                              lowCycle.item(),
                              highCycle.item(),
                              self.perceptLoss.item()
                          )
                          )

                    disInd = np.random.randint(0,6)
                    lrImgImg = (lrImg.cpu().data.numpy()[0, 0, disInd, :, :])
                    lrImgImg = RestoreNetImg(lrImgImg, 0,1)
                    logger.img('lrXY', lrImgImg)
                    gtImg = gt.data.numpy()[0,0,disInd, :, :]
                    gtImg = RestoreNetImg(gtImg, 0, 1)
                    logger.img('gtXY', gtImg)
                    lrImgImg = (fake_A.cpu().data.numpy()[0, 0, disInd, :, :])
                    lrImgImg = RestoreNetImg(lrImgImg, 0,1)
                    logger.img('deXY', lrImgImg)
                    recovImg = recov_B.cpu().data.numpy()[0, 0, disInd, :, :]
                    recovImg = RestoreNetImg(recovImg, 0,1)
                    recovImg2XY = recovImg #np.max(recovImg, axis=0)
                    #recovImg2XZ = np.max(recovImg, axis=1)
                    logger.img('cycHRXY', recovImg2XY)
                    #logger.img('cycHRXZ', recovImg2XZ)
                    recovImg = recov_A.cpu().data.numpy()[0, 0, disInd, :, :]
                    recovImg = RestoreNetImg(recovImg, 0, 1)
                    recovImg2XY = recovImg#np.max(recovImg, axis=0)
                    #recovImg2XZ = np.max(recovImg, axis=1)
                    logger.img('cycLRXY', recovImg2XY)
                    # logger.img('cycLRXZ', recovImg2XZ)
                    reImg = fake_B.cpu().data.numpy()[0, 0, disInd, :, :]
                    reImg = RestoreNetImg(reImg, 0,1)
                    reImg2XY = reImg#np.max(reImg, axis=0)
                    #reImg2XZ = np.max(reImg, axis=1)
                    logger.img('srXY', reImg2XY)
                    # logger.img('srXZ', reImg2XZ)

                    highImgXY = (highImg.data.numpy()[0, 0, disInd, :, :])
                    highImgXY = RestoreNetImg(highImgXY, 0,1)
                    logger.img('highXY', highImgXY)
                    # highImgXZ = np.max(highImg.cpu().data.numpy()[0, 0, :, :, :], axis=1)
                    # highImgXZ = RestoreNetImg(highImgXZ, 0,1)
                    # logger.img('highXZ', highImgXZ)
                    lossVal = float(G_loss.cpu().data.numpy())
                    if np.abs(lossVal) > 200:
                        print('G loss > 200')
                    else:
                        logger.plot('G_loss', lossVal)

                    lossVal = float(D_loss.cpu().data.numpy())
                    if np.abs(lossVal) > 200:
                        print('D loss > 200')
                    else:
                        logger.plot('D_loss', lossVal)
                if self.shot != 0 and self.shot % 500 == 0:
                    if not os.path.exists('saved_models/'):
                        os.mkdir('saved_models/')
                    torch.save(self.G_AB.state_dict(), "saved_models/G_AB_%d.pth" % ( self.shot))
                    torch.save(self.G_BA.state_dict(), "saved_models/G_BA_%d.pth" % ( self.shot))
                    torch.save(self.D_A.state_dict(), "saved_models/D_A_%d.pth" % ( self.shot))
                    torch.save(self.D_B.state_dict(), "saved_models/D_B_%d.pth" % ( self.shot))
        #torch.save(self.net, 'DualGAN.pt')





